#ifndef __ETAP_11_H__
#define __ETAP_11_H__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <elf.h>
#include <assert.h>

void produ_executable(FILE *fp, int flag);

#endif
