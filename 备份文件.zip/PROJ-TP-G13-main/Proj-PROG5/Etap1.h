#ifndef __ETAP_1_H__
#define __ETAP_1_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <elf.h>

void etap1(Elf32_Ehdr* ehdr, FILE * fp, int flag);

#endif
