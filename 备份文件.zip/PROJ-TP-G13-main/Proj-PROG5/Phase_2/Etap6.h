#ifndef __ETAP_6_H__
#define __ETAP_6_H__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <elf.h>
#include <assert.h>

int supprimer_une_section(FILE *fp, char *sec_but, int flag);

#endif
